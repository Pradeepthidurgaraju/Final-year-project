from flask import Flask, render_template, url_for, request
import sqlite3
from pyresparser import ResumeParser
import json
import requests
import time
import pprint

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT name, password FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchall()

        if result:
            return render_template('userlog.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')
            
    return render_template('index.html')


@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
        cursor.execute(command)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/analyse', methods=['GET', 'POST'])
def analyse():
    if request.method == 'POST':
        try:
            filame = request.form['File']
            path = 'static/resumes/'+filame
            
            resume_data = ResumeParser(path).get_extracted_data()
            print(resume_data)

            print('Name: '+resume_data['name'])
            print('Email: ' + resume_data['email'])
            print('Contact: ' + resume_data['mobile_number'])
            print('Skills: {}'.format(resume_data['skills']))

            keys = ['Name', 'Email', 'Contact', 'Skills']
            values = [resume_data['name'], resume_data['email'], resume_data['mobile_number'], resume_data['skills']]

            ds_keyword = ['presentation', 'programming', 'tensorflow','keras','pytorch','machine learning','deep Learning','flask','streamlit']
            web_keyword = ['communication', 'technical', 'react', 'django', 'node jS', 'react js', 'php', 'laravel', 'magento', 'wordpress',
                        'javascript', 'angular js', 'c#', 'c++', 'c', 'flask']
            android_keyword = ['android','android development','flutter','kotlin','xml','kivy']
            ios_keyword = ['ios','ios development','swift','cocoa','cocoa touch','xcode']
            uiux_keyword = ['ux','adobe xd','figma','zeplin','balsamiq','ui','prototyping','wireframes','storyframes','adobe photoshop','photoshop','editing','adobe illustrator','illustrator','adobe after effects','after effects','adobe premier pro','premier pro','adobe indesign','indesign','wireframe','solid','grasp','user research','user experience']

            ds = 0
            web = 0
            android = 0
            ios = 0
            uiux = 0
            labels = ['Data Science', 'Web Development', 'Android Development', 'IOS Development', 'UI-UX Development']


            for i in resume_data['skills']:
                    if i.lower() in ds_keyword:
                        ds += 1

                    elif i.lower() in web_keyword:
                        web += 1

                    elif i.lower() in android_keyword:
                        android += 1

                    elif i.lower() in ios_keyword:
                        ios += 1

                    elif i.lower() in uiux_keyword:
                        uiux += 1

            List = [ds, web, android, ios, uiux]
            index = List.index(max(List))

            return render_template('userlog.html', keys=keys, values=values, job=labels[index])
        except Exception as e:
            print(f"\n\n\n {e} \n\n\n")
            return render_template('userlog.html', msg="Data not found")
    return render_template('leaf.html')

@app.route('/posts/<jb>')
def posts(jb):
    job = jb
    print(job)
    # try:
    timestamp = time.time()
    headers = json.load(open('headers.json'))
    json_filename = './files/timesjobs.json'
    fp = open(json_filename, 'w')

    url = 'https://jobbuzz.timesjobs.com/jobbuzz/loadMoreJobs.json?companyIds=&locationnames=198130$&aosValues=&sortby=Y&from=filter&faids=&txtKeywords='+job+'&pSize=19'
    response = requests.get(url)
    jobs = json.loads(response.text)
    jobs = jobs['jobsList']

    joblist = []
    heading = ['title', 'apply link', 'job description', 'company name', 'location', 'salary', 'skills', 'enddate', 'source', 'experience']
    pprint.pprint(heading)
    for job in jobs:
        row = dict.fromkeys(headers)
        title = job['title']
        applylink = 'http://www.timesjobs.com/candidate/' + job['jdUrl']
        jd = job['jobDesc']
        companyname = job['companyName']
        location = job['Location']
        salary = job['salary']
        skills = ", ".join([x.strip().strip("\"") for x in job['keySkills']])
        enddate = job['expiry']
        source = 'timesjobs'
        experience = job['experience'] + " yrs"
        joblist.append([title, applylink, jd, companyname, location, salary, skills, enddate, source, experience])
        pprint.pprint([title, applylink, jd, companyname, location, salary, skills, enddate, source, experience])            
    json.dump(joblist, fp)
    fp.close()
    return render_template('posts.html', joblist=joblist, heading=heading)

    # except Exception as ex:
    #     print(ex)
    #     return render_template('posts.html', msg='posts not found')

@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
