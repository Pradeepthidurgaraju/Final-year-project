from pyresparser import ResumeParser

data = ResumeParser('resume.pdf').get_extracted_data()
print(data)


 <td><a href="{{ url_for('applied_jobs', In = In) }}" class="form-control btn btn-success">apply</a></td>

 69